import java.util.ArrayList;

/**
 * Created by miratepuffin on 16/03/15.
 */
public class Communication extends Event {

    Event goTo;
    int threadPointer;

    public Communication(int number, int threadContained, Event goTo, int threadPointer,ArrayList<Pair> pairs){

        super(number,threadContained,pairs);
        this.goTo = goTo;
        this.threadPointer = threadPointer;

    }

    public int getThreadPointer() {
        return threadPointer;
    }

    public Event getGoTo() {
        return goTo;
    }

}
