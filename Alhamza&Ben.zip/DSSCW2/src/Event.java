import java.util.ArrayList;
import java.util.HashSet;

/**
 * Created by miratepuffin on 16/03/15.
 */
public class Event {

    private int number;
    private int threadContained;
    Event first = null;
    Event second = null;
    ArrayList<Pair> pairs;

    public Event(int number,int threadContained,ArrayList<Pair>pairs){
        this.number = number;
        this.threadContained = threadContained;
        this.pairs=pairs;
    }

    public int getNumber(){
        return number;
    }


    public int getThreadContained() {
        return threadContained;
    }

    public Event getFirst() {
        return first;
    }

    public void setFirst(Event first) {
        this.first = first;
    }

    public Event getSecond() {
        return second;
    }

    public void setSecond(Event second) {
        this.second = second;
    }

    public void statBuildPairs(){
        checkPrevious(new ArrayList<Integer>());
    }
    private void BuildPairs(ArrayList<Integer> previous){
        for (Integer previou : previous){
//            System.out.println("Inner Build: " + number + " " + previou);
            if(!pairs.contains(new Pair(number, previou)))
                pairs.add(new Pair(number, previou));
	    else break;
        }
        checkPrevious(previous);
    }
    private void checkPrevious(ArrayList<Integer> previous){
        if(first!=null) {

            previous.add(number);
            first.BuildPairs(previous);
            previous = new ArrayList<Integer>();
        }
        if(second != null) {
            previous.add(number);
            second.BuildPairs(previous);

        }
    }

}
