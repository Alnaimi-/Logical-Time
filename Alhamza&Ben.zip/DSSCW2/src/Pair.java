/**
 * Created by miratepuffin on 16/03/15.
 */
public class Pair {

    private int first;
    private int second;

    public Pair(int first, int second){
        this.first=first;
        this.second = second;
    }
    @Override
    public boolean equals(Object pairO){
        if(pairO instanceof Pair){
            Pair pair = (Pair) pairO;
            return (pair.getFirst() == first) && (pair.getSecond() == second);
        }
        return false;
    }
    public int getFirst(){
        return first;
    }

    public int getSecond(){
        return second;
    }

    @Override
    public int hashCode(){
        return (first*31)+(second*31);
    }

}
