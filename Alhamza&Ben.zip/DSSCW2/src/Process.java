import java.util.ArrayList;
import java.util.Random;

/**
 * Created by miratepuffin on 16/03/15.
 */
public class Process extends Thread{

    ArrayList<Event> myEventList;
    ArrayList<TimeLine> timelines;
    int threadNum;
    ArrayList<Communication> comms;
    boolean finished;

    public Process(int threadNum, ArrayList<Event> myEventList,  ArrayList<Communication> comms,ArrayList<TimeLine> timelines){
        this.myEventList = myEventList;
        this.threadNum = threadNum;
        this.comms = comms;
        this.timelines = timelines;
        finished = false;
    }

    @Override
    public void run(){
        Random random = new Random();
        while(true){
            int which = 0;
            boolean ifComm = random.nextBoolean();

            if(ifComm && !comms.isEmpty()){
                TimeLine timeline;
                timeline = timelines.get(threadNum);
                timeline.addFirst(comms.get(which));

                int second = comms.get(which).getThreadPointer();
                timeline = timelines.get(second);
                timeline.addSecond(comms.get(which).getGoTo(), comms.get(which));
                comms.remove(which);
            }

            else if(!myEventList.isEmpty()){
                TimeLine timeline = timelines.get(threadNum);
                timelines.get(threadNum).addFirst(myEventList.get(which));
                myEventList.remove(which);
            }
            else if(myEventList.isEmpty() && comms.isEmpty()) break;
        }

        finished=true;
    }

    public boolean isFinished() {
        return finished;
    }
}
