import java.io.*;
import java.util.ArrayList;
import java.util.Random;

public class Run {

    public static void execute(int th, int ev, int co) {

        //int threads = Integer.parseInt(args[0]);
        //int events = Integer.parseInt(args[1]);
        //int comms = Integer.parseInt(args[2]);

        int threads = th;
        int events = ev;
        int comms = co;


        ArrayList<ArrayList<Event>> eventLists = new ArrayList<>();
        ArrayList<TimeLine> timelines = new ArrayList<>();
        ArrayList<ArrayList<Communication>> commLists = new ArrayList<>();
        ArrayList<Process> processes = new ArrayList<>();
        ArrayList<Pair> pairs = new ArrayList<>();

        for (int i = 0; i < threads; i++) {
            eventLists.add(new ArrayList<Event>());
            timelines.add(new TimeLine());
            commLists.add(new ArrayList<Communication>());
        }


        int eventCount = 0;
        Random random = new Random();
        for (int i = 0; i < events; i++) {
            int temp = random.nextInt(threads);
            eventLists.get(temp).add(new Event(eventCount, temp, pairs));
            eventCount++;
        }

        for (int i = 0; i < comms; i++) {
            int temp = random.nextInt(threads);
            int temp2 = temp;
            while (temp == temp2) {
                temp2 = random.nextInt(threads);
            }
            Event tempEvent = new Event(eventCount, temp2, pairs);
            eventCount++;
            commLists.get(temp).add(new Communication(eventCount, temp, tempEvent, temp2, pairs));
            eventCount++;
        }

        for (int i = 0; i < threads; i++) {
            processes.add(new Process(i, eventLists.get(i), commLists.get(i), timelines));
            processes.get(i).start();
        }
        boolean allFinished = false;
        while (!allFinished) {
            allFinished = true;
            for (int i = 0; i < threads; i++) {
                if (!processes.get(i).isFinished()) {
                    allFinished = false;
                    break;
                }
            }
        }
        int eventTotal = 0;
        int commTotal = 0;
        for (TimeLine temp : timelines) {
            for (int i = 0; i < temp.size(); i++) {
                if (temp.get(i) instanceof Communication) {
                    commTotal++;
                    Communication tempCoom = (Communication) temp.get(i);

                    System.out.println(
                            "Communication " +
                                    tempCoom.getNumber() +
                                    " in thread " +
                                    tempCoom.getThreadContained() +
                                    " pointing to event " +
                                    tempCoom.getGoTo().getNumber() +
                                    " in thread " +
                                    tempCoom.getThreadPointer() +
                                    "."
                    );
                } else {
                    System.out.println(
                            "Event " +
                                    temp.get(i).getNumber() +
                                    " in thread " +
                                    temp.get(i).getThreadContained()
                    );
                    eventTotal++;
                }
            }
        }

//        System.out.println("Total number of Events: " + eventTotal);
//        System.out.println("Total number of Communications: " + commTotal);

        int count = 0;
        for (ArrayList<Communication> temp : commLists) {
//            System.out.println(count + ": " + temp.size());
            count++;
        }

        int i = 0;
        for (TimeLine temp : timelines) {
//            System.out.println("Process: " + i++);
            if (temp.size() != 0)
                temp.get(temp.size() - 1).statBuildPairs();
        }

//        System.out.println("Number of < pairs: " + pairs.size());
//        for(Pair temp : pairs){
//            System.out.println("Pair: " + temp.getFirst() + " " + temp.getSecond());
//        }

        int totalEvents = eventTotal + commTotal;
        int nonPairs = (totalEvents * (totalEvents - 1)) / 2;
        nonPairs = nonPairs - pairs.size();
//        System.out.println("number of || pairs: " + nonPairs);

        String path = "results2.txt";
        File f = new File(path);
        PrintWriter out;
        try {
            if (f.exists() && !f.isDirectory()) {
                out = new PrintWriter(new FileOutputStream(new File(path), true));
                out.println(threads + "," + events + "," + comms + "," + pairs.size() + "," + nonPairs);
                out.close();
            } else {
                out = new PrintWriter(path);
                out.println("Processes,Events,Communications,Pairs,Non-pairs");
                out.println(threads + "," + events + "," + comms + "," + pairs.size() + "," + nonPairs);
                out.close();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        for(int i = 0; i < 1; i++) {
            execute(2, 1, 2);
            System.out.println("Finished: " + (i+1));
        }
    }
}