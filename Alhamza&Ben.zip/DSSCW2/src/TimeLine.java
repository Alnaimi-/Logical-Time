import java.util.ArrayList;

/**
 * Created by miratepuffin on 17/03/15.
 */
public class TimeLine {
    ArrayList<Event> timeLine;

    public TimeLine(){
        this.timeLine = new ArrayList<Event>();
    }

    public synchronized int size(){
        return timeLine.size();
    }

    public synchronized void addFirst(Event event){
        if(timeLine.size()!=0){
        Event previous = timeLine.get(timeLine.size()-1);
        event.setFirst(previous);
        }
        timeLine.add(event);
    }
    public synchronized void addSecond(Event event, Communication previous){
        if(timeLine.size()!=0){
            Event previousE = timeLine.get(timeLine.size()-1);
            event.setFirst(previousE);
        }
        timeLine.add(event);
        event.setSecond(previous);
    }

    public synchronized void remove(int i){
        timeLine.remove(i);
    }
    public synchronized Event get(int i){
        return timeLine.get(i);
    }


}
