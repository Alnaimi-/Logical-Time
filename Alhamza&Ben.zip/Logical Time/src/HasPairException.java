public class HasPairException extends Exception {
    public HasPairException() { super(); }
    public HasPairException(String message) { super(message); }
}