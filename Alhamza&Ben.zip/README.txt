Please note that in the report, two implementations will be described. The initial implementation, which is given by the source code or project in the folder DSSCW2, and the second implentation described at the end, which is given by the source code of Logical Time.

The third folder, R Stuff, contains the graphs displayed in the report, as well as the R code used to produce the said graphs, and the result data used for the graphs and mean calculations.

Also, which in the project DSSCW2, if the number of events given are 10 and number of communications are 20, then 50 events in total will be created, with 20 being a communication, 20 being the receiving events and another additional 10.

However in the project Logical Time, if the number of events given are 50, and the number of communications are 20, then 50 events are created of whcih 20 are a communication!
